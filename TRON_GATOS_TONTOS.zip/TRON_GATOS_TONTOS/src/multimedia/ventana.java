
package multimedia;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



/**
 *
 * @author Alejandro Navarro 233469
 */
public class ventana extends javax.swing.JFrame {

    /**
     * Creates new form ventana
     */
    public ventana() {
        initComponents();
    }
    
    public Image getIconImage() {
        Image imaxe = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("multimedia/gatotonto.jpg"));
        return imaxe;
        }
    
    //TRON hilo;
    TRON hilo =new TRON(6,4,false,0,2,new int[30][54],6,43,false,1);
    int cont=0;
    int cont2=0;
    int ganarojo=0;
    int ganaazul=0;
    
    public void doDrawing(Graphics g){
         try{
            
             InputStream gris = getClass().getResourceAsStream("fondo.png");
             BufferedImage gris2=ImageIO.read(gris);
            InputStream rojo = getClass().getResourceAsStream("rojo.jpg");
             BufferedImage rojo2=ImageIO.read(rojo);
             InputStream azul = getClass().getResourceAsStream("azul.jpg");
             BufferedImage azul2=ImageIO.read(azul);
            //URL rojo = getClass().getResource("rojo.jpg");
            //URL azul = getClass().getResource("azul.jpg");
             
            for(int i=0;i<hilo.grid.length;i++){
                for(int j=0;j<hilo.grid[i].length;j++){
                    if(hilo.comoVa(i, j)==0)
                    //g.drawImage(ImageIO.read(new File("C:\\Users\\Javi\\Documents\\NetBeansProjects\\TRON_ESCRI_GRAF_2\\src\\tron_escri_graf_2\\gris.jpg")),j*15,i*15,this);
                    //g.drawImage(ImageIO.read(new File(".\\gris.jpg").getAbsoluteFile().getParentFile()),j*15,i*15,this);
                    g.drawImage(gris2,j*15,i*15,this);
                    else if(hilo.comoVa(i, j)==2)
                    g.drawImage(azul2,j*15,i*15,this);
                    else
                    g.drawImage(rojo2,j*15,i*15,this);
                }
            }
            Toolkit.getDefaultToolkit().sync();
             
        }catch(Exception e){}
    }
    
    
   public void Recorrer() {
       
            new Thread(new Runnable() {
                @Override
                public void run(){
/*
                for(int i=0;i<grid.length;i++){
                     for(int j=0;j<grid[i].length;j++){
                         grid[i][j]=0;
                     }
                 }*/
                
                while((hilo.getdir()==1||hilo.getdir()==2||hilo.getdir()==3||hilo.getdir()==4)&&
                        (!hilo.choque||!hilo.choque2)&&hilo.posicioni<hilo.grid.length && hilo.posicionj<hilo.grid[0].length
                        ){
                   
                    if(!hilo.choque){
                         cont++;
                    switch(hilo.getdir()){
                         case 1:{
                             //posicionj -=1;
                             //IZQUIERDA
                             hilo.setposj(hilo.posicionj-1);
                             try{
                                if(hilo.grid[hilo.posicioni][hilo.posicionj]==1 ||hilo.grid[hilo.posicioni][hilo.posicionj]==2){
                                   System.out.println("Has chocado. Has perdido ROJO has durado "+cont+" segundos");
                                   hilo.choque=true;

                               }else{
                                    hilo.grid[hilo.getposi()][hilo.getposj()]=1;
                                }

                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista ROJO has durado "+cont+" segundos");
                                 hilo.choque=true;
                            }
                             break;
                         }
                         case 2:{
                             //posicionj+=1;
                             //DERECHA
                             hilo.setposj(hilo.posicionj+1);
                             try{
                                if(hilo.grid[hilo.posicioni][hilo.posicionj]==1||hilo.grid[hilo.posicioni][hilo.posicionj]==2){
                                   System.out.println("Has chocado. Has perdido ROJO has durado "+cont+" segundos");
                                   hilo.choque=true;

                               }else{
                                    hilo.grid[hilo.getposi()][hilo.getposj()]=1;
                                }
                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista ROJO has durado "+cont+" segundos");
                                 hilo.choque=true;
                            }
                             break;
                         }
                         case 3:{
                             //posicioni-=1;
                             //ARRIBA
                             hilo.setposi(hilo.posicioni-1);
                             try{
                                if(hilo.grid[hilo.posicioni][hilo.posicionj]==1||hilo.grid[hilo.posicioni][hilo.posicionj]==2){
                                   System.out.println("Has chocado. Has perdido ROJO has durado "+cont+" segundos");
                                   hilo.choque=true;

                               }else{
                                    hilo.grid[hilo.getposi()][hilo.getposj()]=1;
                                }
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista ROJO has durado "+cont+" segundos");
                                 hilo.choque=true;
                            }
                             break;
                         }
                         case 4:{
                              //posicioni+=1;
                              //ABAJO
                              hilo.setposi(hilo.posicioni+1);
                              try{
                                    if(hilo.grid[hilo.posicioni][hilo.posicionj]==1||hilo.grid[hilo.posicioni][hilo.posicionj]==2){
                                      System.out.println("Has chocado. Has perdido ROJO has durado "+cont+" segundos");
                                      hilo.choque=true;

                                  }else{
                                       hilo.grid[hilo.getposi()][hilo.getposj()]=1;
                                   }
                              
                              }catch(Exception e){
                                 System.out.println("Has salido de la pista ROJO has durado "+cont+" segundos");
                                 hilo.choque=true;
                            }
                             break;
                         }
                     }
                    
                    }   
                    
/*
                 try{
                     hilo.grid[hilo.getposi()][hilo.getposj()]=1;


                 }catch(Exception e){
                     //System.out.println("Has salido de la pista");

                     break;
                 }
                    */
                 //jugador2
                 if(!hilo.choque2){
                     cont2++;
                 switch(hilo.getDireccio2()){
                         case 1:{
                             //posicionj -=1;
                             //IZQUIERDA
                             hilo.setPosicionj2(hilo.posicionj2-1);
                             try{
                                if(hilo.grid[hilo.posicioni2][hilo.posicionj2]==1 || hilo.grid[hilo.posicioni2][hilo.posicionj2]==2){
                                   System.out.println("Has chocado. Has perdido AZUL has durado "+cont+" segundos");
                                   hilo.choque2=true;

                               }else{
                                    hilo.grid[hilo.getPosicioni2()][hilo.getPosicionj2()]=2;
                                }

                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista AZUL has durado "+cont+" segundos");
                                 hilo.choque2=true;
                            }
                             break;
                         }
                         case 2:{
                             //posicionj+=1;
                             //DERECHA
                             hilo.setPosicionj2(hilo.posicionj2+1);
                             try{
                                if(hilo.grid[hilo.posicioni2][hilo.posicionj2]==1 || hilo.grid[hilo.posicioni2][hilo.posicionj2]==2){
                                   System.out.println("Has chocado. Has perdido AZUL has durado "+cont+" segundos");
                                   hilo.choque2=true;

                               }else{
                                    hilo.grid[hilo.getPosicioni2()][hilo.getPosicionj2()]=2;
                                }
                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista AZUL has durado "+cont+" segundos");
                                 hilo.choque2=true;
                            }
                             break;
                         }
                         case 3:{
                             //posicioni-=1;
                             //ARRIBA
                             hilo.setPosicioni2(hilo.posicioni2-1);
                             try{
                                if(hilo.grid[hilo.posicioni2][hilo.posicionj2]==1 || hilo.grid[hilo.posicioni2][hilo.posicionj2]==2){
                                   System.out.println("Has chocado. Has perdido AZUL has durado "+cont+" segundos");
                                   hilo.choque2=true;

                               }else{
                                    hilo.grid[hilo.getPosicioni2()][hilo.getPosicionj2()]=2;
                                }
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista AZUL has durado "+cont+" segundos");
                                 hilo.choque2=true;
                            }
                             break;
                         }
                         case 4:{
                              //posicioni+=1;
                              //ABAJO
                              hilo.setPosicioni2(hilo.posicioni2+1);
                              try{
                                    if(hilo.grid[hilo.posicioni2][hilo.posicionj2]==1 || hilo.grid[hilo.posicioni2][hilo.posicionj2]==2){
                                      System.out.println("Has chocado. Has perdido AZUL has durado "+cont+" segundos");
                                      hilo.choque2=true;

                                  }else{
                                       hilo.grid[hilo.getPosicioni2()][hilo.getPosicionj2()]=2;
                                   }
                              
                              }catch(Exception e){
                                 System.out.println("Has salido de la pista AZUL has durado "+cont+" segundos");
                                 hilo.choque2=true;
                            }
                             break;
                         }
                     }
                 
                 } 
                 //mostrar(grid);
                 
                             try {
                                 repaint();
                                 Thread.sleep(500);
                                 
                             } catch (InterruptedException ex) {
                                 Logger.getLogger(TRON.class.getName()).log(Level.SEVERE, null, ex);
                             }
                    
                    
             }
                String gana="";
                if(cont>cont2){
                    gana="ROJO";
                    ganarojo++;
                }else if(cont2>cont){
                    gana="AZUL";
                    ganaazul++;
                }else{
                    gana="EMPATE";
                }
                JOptionPane.showMessageDialog(null, "GANÓ EL COLOR "+gana, "AVISO", JOptionPane.INFORMATION_MESSAGE);
                //AQUI TENEMOS QUE HACER QUE SALGA EL EMPATE Y NO GANO EL COLOR EMPATE
                marcador.setText("ROJO: "+ganarojo+" - AZUL: "+ganaazul);
                reset.setEnabled(true);
             }
                    },"Hilo").start();
                   
       
       }
    
    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        pantalla = new javax.swing.JPanel(){
            @Override
            public void paintComponent(Graphics g)
            {
                super.paintComponent(g);
                // Do the original draw
                doDrawing(g);

            }
        };
        reset = new javax.swing.JButton();
        marcador = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jButton1.setText("Empezar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        pantalla.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pantallaKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout pantallaLayout = new javax.swing.GroupLayout(pantalla);
        pantalla.setLayout(pantallaLayout);
        pantallaLayout.setHorizontalGroup(
            pantallaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pantallaLayout.setVerticalGroup(
            pantallaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 422, Short.MAX_VALUE)
        );

        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        marcador.setFont(new java.awt.Font("Impact", 1, 14)); // NOI18N

        jTextField3.setText("jTextField3");

        jTextField4.setText("jTextField4");

        label1.setText("TIEMPO ROJO:");

        label2.setText("TIEMPO AZUL:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pantalla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(marcador, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(199, 199, 199)
                                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(395, 395, 395)
                                .addComponent(jButton1)
                                .addGap(18, 18, 18)
                                .addComponent(reset))
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(reset)
                        .addComponent(marcador, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(pantalla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        //hilo =new TRON(6,4,false,0,2,new int[30][54],6,43,false,1);
        hilo.grid[6][4]=1;
        hilo.grid[6][43]=2;
        repaint();
        
        
    }//GEN-LAST:event_formWindowActivated

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        Recorrer();
        pantalla.requestFocus();
        jButton1.setEnabled(false);
        reset.setEnabled(false);
        
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void pantallaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pantallaKeyPressed
        // TODO add your handling code here:
        
        if(evt.getKeyCode()==evt.VK_A){
            
                   hilo.setdir(1);
                   
                   //hilo.posicionj -=1; 
                   //hilo.mostrar(hilo.grid);
                  /*
                   if(hilo.grid[hilo.posicioni][hilo.posicionj]==1){
                       System.out.println("Has chocado. Has perdidoL");
                       hilo.choque=true;
                       
                   }else{
                       hilo.grid[hilo.posicioni][hilo.posicionj]=1;
                       
                   }
            */
           
        }
        if(evt.getKeyCode()==evt.VK_D){
            
                    hilo.setdir(2);
                    
                    //hilo.posicionj+=1;
                    //hilo.mostrar(hilo.grid);
                    /*if( hilo.grid[hilo.posicioni][hilo.posicionj]==1){
                        System.out.println("Has chocado. Has perdidoR");
                        hilo.choque=true;
                        
                    }else{
                        hilo.grid[hilo.posicioni][hilo.posicionj]=1;
                        
                    }*/
        }
        if(evt.getKeyCode()==evt.VK_W){
            
                    hilo.setdir(3);
                    
                    //hilo.posicioni-=1;
                    //hilo.mostrar(hilo.grid);
                   /* if(hilo.grid[hilo.posicioni][hilo.posicionj]==1){
                        System.out.println("Has chocado. Has perdidoU");
                        hilo.choque=true;
                       
                    }else{
                        hilo.grid[hilo.posicioni][hilo.posicionj]=1;
                        
                    }*/
        }
        if(evt.getKeyCode()==evt.VK_S){
            
                    hilo.setdir(4);
                    
                    //hilo.posicioni+=1;
                    //hilo.mostrar(hilo.grid);
                    /*if(hilo.grid[hilo.posicioni][hilo.posicionj]==1){
                        System.out.println("Has chocado. Has perdidoD");
                        hilo.choque=true;
                        
                    }else{
                        hilo.grid[hilo.posicioni][hilo.posicionj]=1;
                        
                    }*/
        }
        
        if(evt.getKeyCode()==evt.VK_LEFT){
            hilo.setDireccio2(1);
            
        }
        
        if(evt.getKeyCode()==evt.VK_RIGHT){
            hilo.setDireccio2(2);
        }
        if(evt.getKeyCode()==evt.VK_UP){
            hilo.setDireccio2(3);
        }
        if(evt.getKeyCode()==evt.VK_DOWN){
            hilo.setDireccio2(4);
        }
        
        repaint();
    }//GEN-LAST:event_pantallaKeyPressed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        for(int i=0;i<hilo.grid.length;i++){
            for(int j=0;j<hilo.grid[i].length;j++){
                hilo.grid[i][j]=0;
            }
        }
        hilo.grid[6][4]=1;
        hilo.grid[6][43]=2;
        
        //TRON hilo =new TRON(6,4,false,0,2,new int[30][54],6,43,false,1);
        cont=0;
        cont2=0;
        hilo.setdir(2);
        hilo.setDireccio2(1);
        hilo.setChoque2(false);
        hilo.choque=false;
        hilo.setposi(6);
        hilo.setposj(4);
        hilo.setPosicioni2(6);
        hilo.setPosicionj2(43);
        //Recorrer();
        repaint();
        jButton1.setEnabled(true);
    }//GEN-LAST:event_resetActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, "Controles ROJO: UP,DOWN,RIGHT,LEFT. AZUL: UP->W,DOWN->S,RIGHT->D,LEFT->A", "AVISO", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_formWindowOpened

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventana().setVisible(true);
               
               
                
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private javax.swing.JLabel marcador;
    private javax.swing.JPanel pantalla;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
}
