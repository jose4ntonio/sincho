
package multimedia;



import java.util.logging.Level;
import java.util.logging.Logger;




/**
 *
 * @author Alejandro Navarro 233469
 */
public class TRON {
       public int posicioni;
       public int posicionj;
       public boolean choque;
       public int contador;
       public int direccio;
       public int grid[][];//=new int[8][8];
       //public char direccion;
       public int posicioni2;
       public int posicionj2;
       public boolean choque2;
       public int direccio2;
       
       public TRON(){
           
       }
       
       public TRON(int posicioni,int posicionj,boolean choque,int contador,int direccio,int grid[][]){
           this.posicioni=posicioni;
           this.posicionj=posicionj;
           this.choque=choque;
           this.contador=contador;
           this.direccio=direccio;
           this.grid=grid;
       }

    public TRON(int posicioni, int posicionj, boolean choque, int contador, int direccio, int[][] grid, int posicioni2, int posicionj2, boolean choque2, int direccio2) {
        this.posicioni = posicioni;
        this.posicionj = posicionj;
        this.choque = choque;
        this.contador = contador;
        this.direccio = direccio;
        this.grid = grid;
        this.posicioni2 = posicioni2;
        this.posicionj2 = posicionj2;
        this.choque2 = choque2;
        this.direccio2 = direccio2;
    }
       
       
       
       
       
       public void setposi(int posi){
           this.posicioni=posi;
       }
       
       public int getposi(){
           return posicioni;
       }
       public void setposj(int posj){
           this.posicionj=posj;
       }
       public int getposj(){
           return posicionj;
       }
       public int getdir(){
           return direccio;
       }
       public void setdir(int direccio){
           this.direccio=direccio;
       }
       
       public int comoVa(int pi,int pj){
           return this.grid[pi][pj];
       }
       
    
     public int devuelvei(int [][] grid){
         return getposi();
     }  
       
     public int devuelvej(int [][] grid){
         
       return getposj();  
     }    
    
     //player2
      public int getPosicioni2() {
        return posicioni2;
    }

    public void setPosicioni2(int posicioni2) {
        this.posicioni2 = posicioni2;
    }

    public int getPosicionj2() {
        return posicionj2;
    }

    public void setPosicionj2(int posicionj2) {
        this.posicionj2 = posicionj2;
    }

    public boolean isChoque2() {
        return choque2;
    }

    public void setChoque2(boolean choque2) {
        this.choque2 = choque2;
    }

    public int getDireccio2() {
        return direccio2;
    }

    public void setDireccio2(int direccio2) {
        this.direccio2 = direccio2;
    }
     
       /*
       public void mostrar(int [][] grid){
          
           
           String text="";
           ventana.pantalla.setText(text);
           for(int i=0;i<grid.length;i++){
            for(int j=0;j<grid[i].length;j++){
                
                if(getposi()==i && getposj()==j){
                    text +="8 ";
                }else{
                    text += Integer.toString(grid[i][j])+" ";
                }
                
            }
            text +="\n";
        }
           ventana.pantalla.setText(text);
                    
                
       }
       
    
       
      /* 
       public void deslizar(char direccion){
       
        
        mostrar(grid);
        while(posicioni<grid.length && posicionj<grid[0].length && !choque  ){
        
        
        contador +=1;
        mostrar(grid);
        try{
            switch(direccion){

                case 'a':{
                    
                   direccio=1;
                   posicionj -=1; 
                   mostrar(grid);
                  
                   if(grid[posicioni][posicionj]==1){
                       System.out.println("Has chocado. Has perdido");
                       choque=true;
                       
                   }else{
                       grid[posicioni][posicionj]=1;
                       
                   }
                    
                   break;
                }
                case 'd':{
                    direccio=2;
                    posicionj+=1;
                    mostrar(grid);
                    if( grid[posicioni][posicionj]==1){
                        System.out.println("Has chocado. Has perdido");
                        choque=true;
                        
                    }else{
                        grid[posicioni][posicionj]=1;
                        
                    }

                    break;
                }
                case 'w':{
                   
                    direccio=3;
                    posicioni-=1;
                    mostrar(grid);
                    if(grid[posicioni][posicionj]==1){
                        System.out.println("Has chocado. Has perdido");
                        choque=true;
                       
                    }else{
                        grid[posicioni][posicionj]=1;
                        
                    }

                    break;
                }
                case 's':{
                    direccio=4;
                    posicioni+=1;
                    mostrar(grid);
                    if(grid[posicioni][posicionj]==1){
                        System.out.println("Has chocado. Has perdido");
                        choque=true;
                        
                    }else{
                        grid[posicioni][posicionj]=1;
                        
                    }

                }
            }
            
        }catch(Exception e){System.out.println("Has salido de la pista1");break;}
        
      
            
                /*
                try{
                
                mostrar2(grid);
                
                }catch(Exception e){
                System.out.println("Has salido de la pista2");
                }
                
                
                
        
        }
        System.out.println("Has girado "+(contador-1)+" veces");
          
                    
       
       }
       */
       
       
 /*      
       
       public void Recorrer() {
            new Thread(new Runnable() {
                @Override
                public void run(){
/*
                for(int i=0;i<grid.length;i++){
                     for(int j=0;j<grid[i].length;j++){
                         grid[i][j]=0;
                     }
                 }
                int cont=0;
                while((getdir()==1||getdir()==2||getdir()==3||getdir()==4)&&!choque&&posicioni<grid.length && posicionj<grid[0].length){
                    cont++;
                    switch(getdir()){
                         case 1:{
                             //posicionj -=1;
                             //IZQUIERDA
                             setposj(posicionj-1);
                             try{
                                if(grid[posicioni][posicionj]==1){
                                   System.out.println("Has chocado. Has perdido51 has durado "+cont+" segundos");
                                   choque=true;

                               }else{
                                    grid[getposi()][getposj()]=1;
                                }

                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista51 has durado "+cont+" segundos");
                                 choque=true;
                            }
                             break;
                         }
                         case 2:{
                             //posicionj+=1;
                             //DERECHA
                             setposj(posicionj+1);
                             try{
                                if(grid[posicioni][posicionj]==1){
                                   System.out.println("Has chocado. Has perdido52 has durado "+cont+" segundos");
                                   choque=true;

                               }else{
                                    grid[getposi()][getposj()]=1;
                                }
                             
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista52 has durado "+cont+" segundos");
                                 choque=true;
                            }
                             break;
                         }
                         case 3:{
                             //posicioni-=1;
                             //ARRIBA
                             setposi(posicioni-1);
                             try{
                                if(grid[posicioni][posicionj]==1){
                                   System.out.println("Has chocado. Has perdido53 has durado "+cont+" segundos");
                                   choque=true;

                               }else{
                                    grid[getposi()][getposj()]=1;
                                }
                             }catch(Exception e){
                                 System.out.println("Has salido de la pista53 has durado "+cont+" segundos");
                                 choque=true;
                            }
                             break;
                         }
                         case 4:{
                              //posicioni+=1;
                              //ABAJO
                              setposi(posicioni+1);
                              try{
                                    if(grid[posicioni][posicionj]==1){
                                      System.out.println("Has chocado. Has perdido54 has durado "+cont+" segundos");
                                      choque=true;

                                  }else{
                                       grid[getposi()][getposj()]=1;
                                   }
                              
                              }catch(Exception e){
                                 System.out.println("Has salido de la pista54 has durado "+cont+" segundos");
                                 choque=true;
                            }
                             break;
                         }
                     }

                 try{
                     grid[getposi()][getposj()]=1;


                 }catch(Exception e){
                     //System.out.println("Has salido de la pista");

                     break;
                 }
                 //mostrar(grid);
                 
                             try {
                                 Thread.sleep(1000);
                                 
                             } catch (InterruptedException ex) {
                                 Logger.getLogger(TRON.class.getName()).log(Level.SEVERE, null, ex);
                             }
                    
                    
             }


             }
                    },"Hilo").start();
                   
       
       }*/

   
    
}
